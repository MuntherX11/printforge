import { NestFactory } from '@nestjs/core';
import { BridgeModule } from './bridge.module';

async function bootstrap() {
  const app = await NestFactory.createApplicationContext(BridgeModule);
  console.log('PrintForge Moonraker Bridge started (Phase 2 stub)');
  console.log('Configure MOONRAKER_URLS in .env to connect printers');

  process.on('SIGTERM', async () => {
    console.log('Bridge shutting down...');
    await app.close();
    process.exit(0);
  });
}
bootstrap();

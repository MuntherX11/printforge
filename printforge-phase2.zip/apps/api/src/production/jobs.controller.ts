import { Controller, Get, Post, Patch, Param, Body, Query, UseGuards } from '@nestjs/common';
import { JobsService } from './jobs.service';
import { JobMaterialsService } from './job-materials.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CreateProductionJobDto, UpdateProductionJobDto, AddJobMaterialDto } from '@printforge/types';
import { PaginationDto } from '../common/dto/pagination.dto';

@Controller('jobs')
@UseGuards(JwtAuthGuard)
export class JobsController {
  constructor(
    private jobsService: JobsService,
    private jobMaterialsService: JobMaterialsService,
  ) {}

  @Post()
  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'OPERATOR')
  create(@Body() dto: CreateProductionJobDto) {
    return this.jobsService.create(dto);
  }

  @Get()
  findAll(@Query() query: PaginationDto, @Query('status') status?: string) {
    return this.jobsService.findAll(query, status);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.jobsService.findOne(id);
  }

  @Patch(':id')
  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'OPERATOR')
  update(@Param('id') id: string, @Body() dto: UpdateProductionJobDto) {
    return this.jobsService.update(id, dto);
  }

  @Post(':id/materials')
  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'OPERATOR')
  addMaterial(@Param('id') id: string, @Body() dto: AddJobMaterialDto) {
    return this.jobMaterialsService.addMaterial(id, dto);
  }

  @Post(':id/calculate-cost')
  @UseGuards(RolesGuard)
  @Roles('ADMIN', 'OPERATOR')
  calculateCost(@Param('id') id: string) {
    return this.jobsService.calculateCost(id);
  }
}

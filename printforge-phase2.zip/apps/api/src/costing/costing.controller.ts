import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { CostingService } from './costing.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('costing')
@UseGuards(JwtAuthGuard)
export class CostingController {
  constructor(private costingService: CostingService) {}

  @Post('estimate')
  estimate(@Body() body: {
    gramsUsed: number;
    printMinutes: number;
    materialId: string;
    printerId?: string;
    colorChanges?: number;
  }) {
    return this.costingService.estimateFromParams(body);
  }
}

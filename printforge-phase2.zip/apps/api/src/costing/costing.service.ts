import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';
import { CostBreakdown } from '@printforge/types';

@Injectable()
export class CostingService {
  constructor(private prisma: PrismaService) {}

  private async getSetting(key: string, defaultValue: string): Promise<string> {
    const setting = await this.prisma.systemSetting.findUnique({ where: { key } });
    return setting?.value ?? defaultValue;
  }

  async calculateJobCost(job: {
    printDuration?: number | null;
    colorChanges: number;
    purgeWasteGrams: number;
    printer?: { hourlyRate: number } | null;
    materials: Array<{ gramsUsed: number; costPerGram: number }>;
  }): Promise<CostBreakdown> {
    const overheadPercent = parseFloat(await this.getSetting('overhead_percent', '15'));
    const purgeWastePerChange = parseFloat(await this.getSetting('purge_waste_grams', '5'));

    // Material cost: sum of all job materials
    const materialCost = job.materials.reduce(
      (sum, m) => sum + m.gramsUsed * m.costPerGram, 0,
    );

    // Machine cost: hourly rate * hours
    const hours = (job.printDuration || 0) / 3600;
    const hourlyRate = job.printer?.hourlyRate || 0;
    const machineCost = hours * hourlyRate;

    // Waste cost (multi-color purge)
    const purgeGrams = job.colorChanges * purgeWastePerChange;
    const avgCostPerGram = job.materials.length > 0
      ? job.materials.reduce((sum, m) => sum + m.costPerGram, 0) / job.materials.length
      : 0;
    const wasteCost = purgeGrams * avgCostPerGram;

    // Overhead
    const overheadCost = (materialCost + machineCost + wasteCost) * (overheadPercent / 100);

    // Total
    const totalCost = materialCost + machineCost + wasteCost + overheadCost;

    return {
      materialCost: Math.round(materialCost * 1000) / 1000,
      machineCost: Math.round(machineCost * 1000) / 1000,
      wasteCost: Math.round(wasteCost * 1000) / 1000,
      overheadCost: Math.round(overheadCost * 1000) / 1000,
      totalCost: Math.round(totalCost * 1000) / 1000,
    };
  }

  async estimateFromParams(params: {
    gramsUsed: number;
    printMinutes: number;
    materialId: string;
    printerId?: string;
    colorChanges?: number;
  }): Promise<CostBreakdown & { suggestedPrice: number; marginPercent: number }> {
    const material = await this.prisma.material.findUnique({ where: { id: params.materialId } });
    const printer = params.printerId
      ? await this.prisma.printer.findUnique({ where: { id: params.printerId } })
      : null;

    const defaultMargin = parseFloat(await this.getSetting('default_margin_percent', '40'));

    const breakdown = await this.calculateJobCost({
      printDuration: params.printMinutes * 60,
      colorChanges: params.colorChanges || 0,
      purgeWasteGrams: 0,
      printer: printer ? { hourlyRate: printer.hourlyRate } : null,
      materials: material
        ? [{ gramsUsed: params.gramsUsed, costPerGram: material.costPerGram }]
        : [],
    });

    const suggestedPrice = breakdown.totalCost * (1 + defaultMargin / 100);

    return {
      ...breakdown,
      suggestedPrice: Math.round(suggestedPrice * 1000) / 1000,
      marginPercent: defaultMargin,
    };
  }
}

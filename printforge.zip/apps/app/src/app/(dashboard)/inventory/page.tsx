'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Loading } from '@/components/ui/loading';
import { api } from '@/lib/api';
import { formatCurrency } from '@/lib/utils';
import { Plus, Package, AlertTriangle } from 'lucide-react';

export default function InventoryPage() {
  const [materials, setMaterials] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<any[]>('/materials').then(setMaterials).catch(console.error).finally(() => setLoading(false));
  }, []);

  if (loading) return <Loading />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Inventory</h1>
        <Link href="/inventory/new">
          <Button><Plus className="h-4 w-4 mr-2" /> Add Material</Button>
        </Link>
      </div>

      <Card>
        <CardContent className="p-0">
          {materials.length === 0 ? (
            <div className="py-12 text-center text-gray-500">
              <Package className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <p>No materials added yet</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Material</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Color</TableHead>
                  <TableHead>Cost/g</TableHead>
                  <TableHead>Active Spools</TableHead>
                  <TableHead>Total Stock (g)</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {materials.map((m) => {
                  const totalStock = (m.spools || []).reduce((sum: number, s: any) => sum + s.currentWeight, 0);
                  const isLow = totalStock < m.reorderPoint;
                  return (
                    <TableRow key={m.id}>
                      <TableCell>
                        <Link href={`/inventory/${m.id}`} className="font-medium text-brand-600 hover:underline">
                          {m.name}
                        </Link>
                        {m.brand && <p className="text-xs text-gray-500">{m.brand}</p>}
                      </TableCell>
                      <TableCell><Badge className="bg-gray-100 text-gray-700">{m.type}</Badge></TableCell>
                      <TableCell>{m.color || '-'}</TableCell>
                      <TableCell>{formatCurrency(m.costPerGram)}/g</TableCell>
                      <TableCell>{m._count?.spools || 0}</TableCell>
                      <TableCell className="font-mono">{Math.round(totalStock)}g</TableCell>
                      <TableCell>
                        {isLow ? (
                          <Badge className="bg-red-100 text-red-700">
                            <AlertTriangle className="h-3 w-3 mr-1" /> Low Stock
                          </Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-700">OK</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

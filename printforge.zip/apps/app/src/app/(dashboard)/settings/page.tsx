'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loading } from '@/components/ui/loading';
import { api } from '@/lib/api';

export default function SettingsPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get<Record<string, string>>('/settings').then(setSettings).catch(console.error).finally(() => setLoading(false));
  }, []);

  async function handleSave(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const form = new FormData(e.currentTarget);
    const entries = Array.from(form.entries()).map(([key, value]) => ({ key, value: value as string }));
    try {
      await api.put('/settings', { settings: entries });
      alert('Settings saved');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <Loading />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <div className="flex gap-2">
          <Link href="/settings/users"><Button variant="outline">User Management</Button></Link>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <Card>
          <CardHeader><CardTitle>Company</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Input name="company_name" label="Company Name" defaultValue={settings.company_name || ''} />
            <Input name="company_address" label="Address" defaultValue={settings.company_address || ''} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Financial</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <Input name="currency" label="Currency" defaultValue={settings.currency || 'OMR'} />
              <Input name="tax_rate" label="Tax Rate (%)" type="number" step="0.1" defaultValue={settings.tax_rate || '0'} />
              <Input name="overhead_percent" label="Overhead (%)" type="number" step="0.1" defaultValue={settings.overhead_percent || '15'} />
            </div>
            <Input name="default_margin_percent" label="Default Quote Margin (%)" type="number" step="0.1" defaultValue={settings.default_margin_percent || '40'} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Printing</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input name="purge_waste_grams" label="Purge Waste per Color Change (g)" type="number" step="0.1" defaultValue={settings.purge_waste_grams || '5'} />
              <Input name="default_infill_percent" label="Default Infill % (for STL estimation)" type="number" defaultValue={settings.default_infill_percent || '20'} />
            </div>
          </CardContent>
        </Card>

        <Button type="submit" disabled={saving}>{saving ? 'Saving...' : 'Save Settings'}</Button>
      </form>
    </div>
  );
}

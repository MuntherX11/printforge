import { Module } from '@nestjs/common';
import { MaterialsController } from './materials.controller';
import { MaterialsService } from './materials.service';
import { SpoolsController } from './spools.controller';
import { SpoolsService } from './spools.service';

@Module({
  controllers: [MaterialsController, SpoolsController],
  providers: [MaterialsService, SpoolsService],
  exports: [MaterialsService, SpoolsService],
})
export class InventoryModule {}

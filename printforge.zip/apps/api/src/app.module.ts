import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './common/prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { CustomersModule } from './customers/customers.module';
import { InventoryModule } from './inventory/inventory.module';
import { PrintersModule } from './printers/printers.module';
import { ProductionModule } from './production/production.module';
import { CostingModule } from './costing/costing.module';
import { QuotesModule } from './quotes/quotes.module';
import { OrdersModule } from './orders/orders.module';
import { InvoicesModule } from './invoices/invoices.module';
import { AccountingModule } from './accounting/accounting.module';
import { AttachmentsModule } from './attachments/attachments.module';
import { NotificationsModule } from './notifications/notifications.module';
import { SettingsModule } from './settings/settings.module';
import { AuditModule } from './audit/audit.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    UsersModule,
    CustomersModule,
    InventoryModule,
    PrintersModule,
    ProductionModule,
    CostingModule,
    QuotesModule,
    OrdersModule,
    InvoicesModule,
    AccountingModule,
    AttachmentsModule,
    NotificationsModule,
    SettingsModule,
    AuditModule,
  ],
})
export class AppModule {}
